<?php
return [
	'Imagify\Avif\ServiceProvider',
	'Imagify\CDN\ServiceProvider',
	'Imagify\Picture\ServiceProvider',
	'Imagify\Stats\ServiceProvider',
	'Imagify\Webp\ServiceProvider',
];
