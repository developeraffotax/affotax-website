import ChoosePackage from "./Components/ChoosePackage/ChoosePackage";
import HomeTop from "./Components/Home/HomeTop";
import HowItWorks from "./Components/Home/HowItWorks";
import ServicesTo from "./Components/Home/ServicesTo";
import WhyUs from "./Components/Home/WhyUs";
import Layout from "./Components/Layout";

export default function Home() {
  return (
    
    <Layout>
      <HomeTop />
      <ChoosePackage />
      <HowItWorks />
      <WhyUs />
      <ServicesTo />
    </Layout>
    
  );
}
